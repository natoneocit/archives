function aug0323() {
    var checkBox = document.getElementById("aug-03-23");
    var text = document.getElementById("aug-03-23-log");
  
    if (checkBox.checked == true){
      text.style.display = "block";
    } else {
      text.style.display = "none";
    }
  }
  function aug2222() {
    var checkBox = document.getElementById("aug-22-22");
    var text = document.getElementById("aug-22-22-log");
  
    if (checkBox.checked == true){
      text.style.display = "block";
    } else {
      text.style.display = "none";
    }
  }
  function aug1022() {
    var checkBox = document.getElementById("aug-10-22");
    var text = document.getElementById("aug-10-22-log");
  
    if (checkBox.checked == true){
      text.style.display = "block";
    } else {
      text.style.display = "none";
    }
  }
  function aug0322() {
    var checkBox = document.getElementById("aug-03-22");
    var text = document.getElementById("aug-03-22-log");
  
    if (checkBox.checked == true){
      text.style.display = "block";
    } else {
      text.style.display = "none";
    }
  }